// @ts-check
const { themes: prismThemes } = require('prism-react-renderer');

// Derive url/baseUrl from GitLab Pages env so the site works regardless of the
// project's path slug (GitLab Pages serves at /<project-path>/).
// CI_PAGES_URL looks like: https://<namespace>.<pages-domain>/<project-path>
const pagesUrl = process.env.CI_PAGES_URL;
let siteUrl = 'https://gitlab.lan';
let siteBaseUrl = '/';
// Only trust CI_PAGES_URL when this is genuinely report-rex's own GitLab
// Pages build (job "build-docs") -- CI_PAGES_URL is a GitLab predefined
// variable present in every job of every project, so naively trusting it
// breaks when this same `npm run build` runs inside a different project's
// pipeline (e.g. rex-infra building docs for its own nginx-at-root
// deployment) and picks up that other project's Pages path instead.
if (pagesUrl && process.env.CI_JOB_NAME === 'build-docs') {
  const u = new URL(pagesUrl);
  siteUrl = u.origin;
  siteBaseUrl = u.pathname.endsWith('/') ? u.pathname : `${u.pathname}/`;
}
const projectUrl =
  process.env.CI_PROJECT_URL || 'https://gitlab.lan/root/report-rex';

/** @type {import('@docusaurus/types').Config} */
const config = {
  title: 'Report Rex',
  tagline: 'Professional pentest reports from Markdown',
  favicon: 'img/favicon.png',

  url: siteUrl,
  baseUrl: siteBaseUrl,

  organizationName: process.env.CI_PROJECT_NAMESPACE || 'root',
  projectName: process.env.CI_PROJECT_NAME || 'report-rex',

  onBrokenLinks: 'throw',
  onBrokenMarkdownLinks: 'warn',

  i18n: {
    defaultLocale: 'en',
    locales: ['en'],
  },

  presets: [
    [
      'classic',
      /** @type {import('@docusaurus/preset-classic').Options} */
      ({
        docs: {
          routeBasePath: '/',
          sidebarPath: require.resolve('./sidebars.js'),
          editUrl: `${projectUrl}/-/edit/main/docs/`,
        },
        blog: false,
        theme: {
          customCss: require.resolve('./src/css/custom.css'),
        },
      }),
    ],
  ],

  themeConfig:
    /** @type {import('@docusaurus/preset-classic').ThemeConfig} */
    ({
      navbar: {
        title: 'Report Rex',
        logo: {
          alt: 'Report Rex Logo',
          src: 'img/logo.png',
        },
        items: [
          {
            type: 'docSidebar',
            sidebarId: 'docs',
            position: 'left',
            label: 'Documentation',
          },
          {
            href: projectUrl,
            label: 'GitLab',
            position: 'right',
          },
        ],
      },
      footer: {
        style: 'dark',
        links: [
          {
            title: 'Docs',
            items: [
              { label: 'Getting Started', to: '/getting-started/cli' },
              { label: 'Creating Templates', to: '/creating-templates/overview' },
            ],
          },
          {
            title: 'Project',
            items: [
              { label: 'GitLab', href: projectUrl },
              { label: 'Issues', href: `${projectUrl}/-/issues` },
            ],
          },
        ],
        copyright: `Copyright © ${new Date().getFullYear()} Report Rex. Built with Docusaurus.`,
      },
      prism: {
        theme: prismThemes.github,
        darkTheme: prismThemes.dracula,
        additionalLanguages: ['bash', 'yaml', 'latex', 'lua'],
      },
    }),
};

module.exports = config;
