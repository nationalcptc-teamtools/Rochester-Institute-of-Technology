---
sidebar_position: 3
---

# CI/CD

Report Rex ships with a `.gitlab-ci.yml` that handles linting, testing, documentation
deployment, and package/image/CLI publishing.

## Stages

| Stage | Jobs | Runs on |
|-------|------|---------|
| `prepare` | `build-ci-image` | When `Dockerfile.ci` changes, or manual/scheduled |
| `lint` | `ruff`, `vale`, `vuln-templates`, `lint-go`, `lint-vscode` | Every push (`lint-vscode` only on `cli/editors/vscode/**` changes) |
| `test` | `unit-tests`, `test-go`, `test-vscode`, `e2e-cli`, `e2e-ingest`, `e2e-sync`, `render-test` | Every push (`test-vscode` only on `cli/editors/vscode/**` changes; `e2e-sync` only on `cli/**` changes) |
| `build-docs` | `build-docs` | `main` + merge requests |
| `publish` | `pages`, `publish-package`, `publish-docker`, `publish-cli`, `publish-vscode-extension` | `main` (`pages`) / version tags (the rest) |

`build-ci-image` builds a cached pandoc + LaTeX image (via Kaniko) and pushes it to
the project's container registry so `render-test` has a fast, reproducible environment
(currently a TODO in `.gitlab-ci.yml` — `render-test` still runs against the upstream
`pandoc/latex:3.6` image directly until the runner's Docker daemon is configured to
trust the project's own registry).

## Lint jobs

| Job | What it checks |
|-----|-----------------|
| `ruff` | `ruff check core/src/` |
| `vale` | Prose style (`vale --config .vale.ini`) over `reporting/`, `docs/docs/`, `vuln-templates/` |
| `vuln-templates` | `python scripts/check_vuln_templates.py` — validates the built-in vulnerability templates |
| `lint-go` | `gofmt -l .` (must be empty) and `go vet ./...` for `cli/` |
| `lint-vscode` | `npm run lint` for the VS Code extension. Only runs when `cli/editors/vscode/**` changes |

## Test jobs

| Job | What it exercises |
|-----|--------------------|
| `unit-tests` | `pytest core/tests/ -v` with coverage, reported as a Cobertura artifact |
| `test-go` | `go build ./...` and `go test ./... -v -cover` for `cli/` |
| `test-vscode` | Builds and runs the VS Code extension's `node:test` suite. Only runs when `cli/editors/vscode/**` changes |
| `e2e-cli` | Builds the real `rex` binary against a live Docker daemon and drives `rex image build` / `rex report init` end-to-end |
| `e2e-ingest` | Builds the real `rex` binary and runs `rex ingest nmap`/`rex ingest naabu` against `scanme.nmap.org` (nmap's own public test target) into a scaffolded report, verifying `artifacts/assets.json`, `appendices/assets.md`, and the `index.md` registration all come out right. Passes the resulting report directory to `render-test` as an artifact — see below |
| `e2e-sync` | Builds real `rex`/`rex-svr` binaries and drives them as subprocesses through the `-tags e2e` sync test suite (push/pull, conflict + resolve, restart-mid-session drift repair). Only runs when `cli/**` changes |
| `render-test` | Runs the full pandoc → XeLaTeX pipeline against every template, producing real PDFs as artifacts. Also builds `e2e-ingest`'s scanned report into a PDF, closing the ingest → render loop with a real render rather than just file-existence checks |

Both `cli/`-related test jobs and `lint-go` run `bash cli/scripts/prepare-embed.sh`
first — this re-syncs the Dockerfile/`core/`/`templates/`/example scaffolds into
the gitignored `cli/internal/embedded/data/` directory that `go:embed` needs,
since that directory is never committed.

`e2e-ingest` and `render-test` split the ingest → render smoke test across two jobs
rather than doing both in one: `e2e-ingest`'s image has Go, nmap, and naabu but no
pandoc/XeLaTeX, and rendering the scanned report there would hit the same
Docker-in-Docker bind-mount limitation documented on `e2e-cli` (a path inside that
job's own container isn't visible at the same path to the host's Docker daemon).
`render-test`'s image already has pandoc/XeLaTeX installed and renders natively
(`report-rex build`, no Docker involved), so it picks up `e2e-ingest`'s report
directory as an artifact and builds it there instead.

## GitLab Pages

The `pages` job deploys the Docusaurus site automatically on every push to `main`. It moves the `docs/build/` output to `public/`, which GitLab serves at your Pages URL.

`docs/docusaurus.config.js` derives `url` and `baseUrl` automatically from the
`CI_PAGES_URL` predefined variable, so no manual editing is needed — the site works
regardless of the project's Pages path slug. For local builds it falls back to the
current project slug.

## Publishing a Release

Tag a commit with a semantic version to trigger package, Docker image, and CLI publishing:

```bash
git tag v1.0.0
git push origin v1.0.0
```

This runs four jobs in the `publish` stage:

- **`publish-package`** — builds a Python wheel and uploads `report-rex-core` to
  this project's PyPI package registry via `twine`. Skips the upload (rather than
  failing) if that exact version is already published, since `report-rex-core`'s
  version doesn't move in lockstep with `version.txt`/the Go CLI's tags.
- **`publish-docker`** — builds the runtime image (via Kaniko) and pushes it to
  this project's container registry as both the version tag and `latest`, e.g.
  `<registry>/report-rex:latest`.
- **`publish-cli`** — cross-compiles the `rex`/`rex-svr` binaries for all 5
  target platforms with GoReleaser and publishes them as a GitLab Release
  (requires a `GITLAB_TOKEN` CI/CD variable with `api` scope).
- **`publish-vscode-extension`** — packages the `rex-presence` VS Code
  extension (`cli/editors/vscode/`) and uploads the `.vsix` to this project's
  Generic Package Registry via the same `CI_JOB_TOKEN` auth `publish-package`
  uses. Skips the upload if that exact version is already published, since
  the extension's `package.json` version also doesn't move in lockstep with
  `version.txt`. This is the extension's only distribution channel — it
  isn't published to the VS Code Marketplace (see [VS
  Code](../getting-started/ide/vscode.md#installing)).

The registry hosts and credentials these jobs target (`$CI_REGISTRY`,
`$CI_REGISTRY_IMAGE`, `$CI_API_V4_URL`, etc.) are GitLab predefined variables —
they resolve to whatever GitLab instance and project you're running in, so
nothing in `.gitlab-ci.yml` is hardcoded to a specific external domain. If your
GitLab instance uses a private CA or isn't publicly resolvable from the
runner, `publish-package` supports two optional CI/CD variables to work
around that: `GITLAB_HOST_IP` (injects a private IP into `/etc/hosts`) and
`GITLAB_TRUST_INTERNAL_CA` (`"true"` to fetch and trust the instance's TLS
leaf certificate for `twine`'s upload). Both default to off.

## Building Reports in CI

To generate PDFs inside a pipeline (e.g., for automated client reporting):

```yaml
generate-report:
  image: <registry>/report-rex:latest
  script:
    - report-rex build
        --dir reporting/my-engagement
        --output report.pdf
        --skip-validation
  artifacts:
    paths:
      - report.pdf
    expire_in: 30 days
```

Replace `<registry>/report-rex:latest` with your own project's published image
(see `publish-docker` above) — call the Python CLI directly inside the job
rather than the Go CLI's `rex report build` or `./build.sh`, since Docker-in-Docker
isn't needed (or usually available) when the job is already running inside the
`report-rex` image itself.
