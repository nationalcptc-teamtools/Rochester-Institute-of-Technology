package cmd

import (
	"fmt"

	"github.com/spf13/cobra"
	"gitlab.ritsec.cloud/cptc/report-rex/cli/internal/version"
)

var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "Print the report-rex CLI version",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println(version.Version)
	},
}

func init() {
	rootCmd.AddCommand(versionCmd)
}
