// Package cmd wires up the report-rex CLI's Cobra command tree.
package cmd

import (
	"fmt"
	"os"

	"github.com/spf13/cobra"
	"gitlab.ritsec.cloud/cptc/report-rex/cli/internal/version"
)

var rootCmd = &cobra.Command{
	Use:     "rex",
	Short:   "Standalone CLI for building report-rex pentest reports",
	Version: version.Version,
}

// Execute runs the root command, exiting the process on error.
func Execute() {
	if err := rootCmd.Execute(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
