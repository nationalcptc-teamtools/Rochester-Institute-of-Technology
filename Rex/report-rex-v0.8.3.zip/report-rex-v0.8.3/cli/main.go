package main

import "gitlab.ritsec.cloud/cptc/report-rex/cli/cmd"

func main() {
	cmd.Execute()
}
