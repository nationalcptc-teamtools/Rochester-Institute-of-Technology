package cvss

import "math"

// epsilon compensates for float error before rounding half away from zero,
// matching the reference implementation.
const epsilon = 1e-6

// MetricValues are the CVSS v4.0 metric value domains.
var MetricValues = map[string][]string{
	"AV": {"N", "A", "L", "P"},
	"AC": {"L", "H"},
	"AT": {"N", "P"},
	"PR": {"N", "L", "H"},
	"UI": {"N", "P", "A"},
	"VC": {"H", "L", "N"},
	"VI": {"H", "L", "N"},
	"VA": {"H", "L", "N"},
	"SC": {"H", "L", "N"},
	"SI": {"H", "L", "N"},
	"SA": {"H", "L", "N"},
	"E":  {"X", "A", "P", "U"},
	"CR": {"X", "H", "M", "L"},
	"IR": {"X", "H", "M", "L"},
	"AR": {"X", "H", "M", "L"},

	"MAV": {"X", "N", "A", "L", "P"},
	"MAC": {"X", "L", "H"},
	"MAT": {"X", "N", "P"},
	"MPR": {"X", "N", "L", "H"},
	"MUI": {"X", "N", "P", "A"},
	"MVC": {"X", "H", "L", "N"},
	"MVI": {"X", "H", "L", "N"},
	"MVA": {"X", "H", "L", "N"},
	"MSC": {"X", "H", "L", "N"},
	"MSI": {"X", "S", "H", "L", "N"},
	"MSA": {"X", "S", "H", "L", "N"},
}

// BaseMetrics are the 11 CVSS v4.0 base metrics.
var BaseMetrics = []string{
	"AV", "AC", "AT", "PR", "UI", "VC", "VI", "VA", "SC", "SI", "SA",
}

// lookup maps a 6-digit MacroVector to its base score (270 entries).
var lookup = map[string]float64{
	"000000": 10, "000001": 9.9, "000010": 9.8, "000011": 9.5, "000020": 9.5, "000021": 9.2,
	"000100": 10, "000101": 9.6, "000110": 9.3, "000111": 8.7, "000120": 9.1, "000121": 8.1,
	"000200": 9.3, "000201": 9, "000210": 8.9, "000211": 8, "000220": 8.1, "000221": 6.8,
	"001000": 9.8, "001001": 9.5, "001010": 9.5, "001011": 9.2, "001020": 9, "001021": 8.4,
	"001100": 9.3, "001101": 9.2, "001110": 8.9, "001111": 8.1, "001120": 8.1, "001121": 6.5,
	"001200": 8.8, "001201": 8, "001210": 7.8, "001211": 7, "001220": 6.9, "001221": 4.8,
	"002001": 9.2, "002011": 8.2, "002021": 7.2, "002101": 7.9, "002111": 6.9, "002121": 5,
	"002201": 6.9, "002211": 5.5, "002221": 2.7, "010000": 9.9, "010001": 9.7, "010010": 9.5,
	"010011": 9.2, "010020": 9.2, "010021": 8.5, "010100": 9.5, "010101": 9.1, "010110": 9,
	"010111": 8.3, "010120": 8.4, "010121": 7.1, "010200": 9.2, "010201": 8.1, "010210": 8.2,
	"010211": 7.1, "010220": 7.2, "010221": 5.3, "011000": 9.5, "011001": 9.3, "011010": 9.2,
	"011011": 8.5, "011020": 8.5, "011021": 7.3, "011100": 9.2, "011101": 8.2, "011110": 8,
	"011111": 7.2, "011120": 7, "011121": 5.9, "011200": 8.4, "011201": 7, "011210": 7.1,
	"011211": 5.2, "011220": 5, "011221": 3, "012001": 8.6, "012011": 7.5, "012021": 5.2,
	"012101": 7.1, "012111": 5.2, "012121": 2.9, "012201": 6.3, "012211": 2.9, "012221": 1.7,
	"100000": 9.8, "100001": 9.5, "100010": 9.4, "100011": 8.7, "100020": 9.1, "100021": 8.1,
	"100100": 9.4, "100101": 8.9, "100110": 8.6, "100111": 7.4, "100120": 7.7, "100121": 6.4,
	"100200": 8.7, "100201": 7.5, "100210": 7.4, "100211": 6.3, "100220": 6.3, "100221": 4.9,
	"101000": 9.4, "101001": 8.9, "101010": 8.8, "101011": 7.7, "101020": 7.6, "101021": 6.7,
	"101100": 8.6, "101101": 7.6, "101110": 7.4, "101111": 5.8, "101120": 5.9, "101121": 5,
	"101200": 7.2, "101201": 5.7, "101210": 5.7, "101211": 5.2, "101220": 5.2, "101221": 2.5,
	"102001": 8.3, "102011": 7, "102021": 5.4, "102101": 6.5, "102111": 5.8, "102121": 2.6,
	"102201": 5.3, "102211": 2.1, "102221": 1.3, "110000": 9.5, "110001": 9, "110010": 8.8,
	"110011": 7.6, "110020": 7.6, "110021": 7, "110100": 9, "110101": 7.7, "110110": 7.5,
	"110111": 6.2, "110120": 6.1, "110121": 5.3, "110200": 7.7, "110201": 6.6, "110210": 6.8,
	"110211": 5.9, "110220": 5.2, "110221": 3, "111000": 8.9, "111001": 7.8, "111010": 7.6,
	"111011": 6.7, "111020": 6.2, "111021": 5.8, "111100": 7.4, "111101": 5.9, "111110": 5.7,
	"111111": 5.7, "111120": 4.7, "111121": 2.3, "111200": 6.1, "111201": 5.2, "111210": 5.7,
	"111211": 2.9, "111220": 2.4, "111221": 1.6, "112001": 7.1, "112011": 5.9, "112021": 3,
	"112101": 5.8, "112111": 2.6, "112121": 1.5, "112201": 2.3, "112211": 1.3, "112221": 0.6,
	"200000": 9.3, "200001": 8.7, "200010": 8.6, "200011": 7.2, "200020": 7.5, "200021": 5.8,
	"200100": 8.6, "200101": 7.4, "200110": 7.4, "200111": 6.1, "200120": 5.6, "200121": 3.4,
	"200200": 7, "200201": 5.4, "200210": 5.2, "200211": 4, "200220": 4, "200221": 2.2,
	"201000": 8.5, "201001": 7.5, "201010": 7.4, "201011": 5.5, "201020": 6.2, "201021": 5.1,
	"201100": 7.2, "201101": 5.7, "201110": 5.5, "201111": 4.1, "201120": 4.6, "201121": 1.9,
	"201200": 5.3, "201201": 3.6, "201210": 3.4, "201211": 1.9, "201220": 1.9, "201221": 0.8,
	"202001": 6.4, "202011": 5.1, "202021": 2, "202101": 4.7, "202111": 2.1, "202121": 1.1,
	"202201": 2.4, "202211": 0.9, "202221": 0.4, "210000": 8.8, "210001": 7.5, "210010": 7.3,
	"210011": 5.3, "210020": 6, "210021": 5, "210100": 7.3, "210101": 5.5, "210110": 5.9,
	"210111": 4, "210120": 4.1, "210121": 2, "210200": 5.4, "210201": 4.3, "210210": 4.5,
	"210211": 2.2, "210220": 2, "210221": 1.1, "211000": 7.5, "211001": 5.5, "211010": 5.8,
	"211011": 4.5, "211020": 4, "211021": 2.1, "211100": 6.1, "211101": 5.1, "211110": 4.8,
	"211111": 1.8, "211120": 2, "211121": 0.9, "211200": 4.6, "211201": 1.8, "211210": 1.7,
	"211211": 0.7, "211220": 0.8, "211221": 0.2, "212001": 5.3, "212011": 2.4, "212021": 1.4,
	"212101": 2.4, "212111": 1.2, "212121": 0.5, "212201": 1, "212211": 0.3, "212221": 0.1,
}

// maxComposed lists the highest-severity composed vector(s) per MacroVector value.
var maxComposed = map[string]map[string][]string{
	"eq1": {
		"0": {"AV:N/PR:N/UI:N/"},
		"1": {"AV:A/PR:N/UI:N/", "AV:N/PR:L/UI:N/", "AV:N/PR:N/UI:P/"},
		"2": {"AV:P/PR:N/UI:N/", "AV:A/PR:L/UI:P/"},
	},
	"eq2": {
		"0": {"AC:L/AT:N/"},
		"1": {"AC:H/AT:N/", "AC:L/AT:P/"},
	},
	"eq4": {
		"0": {"SC:H/SI:S/SA:S/"},
		"1": {"SC:H/SI:H/SA:H/"},
		"2": {"SC:L/SI:L/SA:L/"},
	},
	"eq5": {
		"0": {"E:A/"},
		"1": {"E:P/"},
		"2": {"E:U/"},
	},
}

// maxComposedEq3 mirrors Python's MAX_COMPOSED["eq3"][eq3][eq6] -> []string.
var maxComposedEq3 = map[string]map[string][]string{
	"0": {
		"0": {"VC:H/VI:H/VA:H/CR:H/IR:H/AR:H/"},
		"1": {"VC:H/VI:H/VA:L/CR:M/IR:M/AR:H/", "VC:H/VI:H/VA:H/CR:M/IR:M/AR:M/"},
	},
	"1": {
		"0": {"VC:L/VI:H/VA:H/CR:H/IR:H/AR:H/", "VC:H/VI:L/VA:H/CR:H/IR:H/AR:H/"},
		"1": {
			"VC:L/VI:H/VA:L/CR:H/IR:M/AR:H/",
			"VC:L/VI:H/VA:H/CR:H/IR:M/AR:M/",
			"VC:H/VI:L/VA:H/CR:M/IR:H/AR:M/",
			"VC:H/VI:L/VA:L/CR:M/IR:H/AR:H/",
			"VC:L/VI:L/VA:H/CR:H/IR:H/AR:M/",
		},
	},
	"2": {
		"1": {"VC:L/VI:L/VA:L/CR:H/IR:H/AR:H/"},
	},
}

// maxSeverity gives the max severity distance (in steps of 0.1) available within each EQ.
var maxSeverityEq1 = map[int]int{0: 1, 1: 4, 2: 5}
var maxSeverityEq2 = map[int]int{0: 1, 1: 2}
var maxSeverityEq3Eq6 = map[int]map[int]int{
	0: {0: 7, 1: 6},
	1: {0: 8, 1: 8},
	2: {1: 10},
}
var maxSeverityEq4 = map[int]int{0: 6, 1: 5, 2: 4}

var avLevels = map[string]float64{"N": 0.0, "A": 0.1, "L": 0.2, "P": 0.3}
var prLevels = map[string]float64{"N": 0.0, "L": 0.1, "H": 0.2}
var uiLevels = map[string]float64{"N": 0.0, "P": 0.1, "A": 0.2}
var acLevels = map[string]float64{"L": 0.0, "H": 0.1}
var atLevels = map[string]float64{"N": 0.0, "P": 0.1}
var vcLevels = map[string]float64{"H": 0.0, "L": 0.1, "N": 0.2}
var viLevels = map[string]float64{"H": 0.0, "L": 0.1, "N": 0.2}
var vaLevels = map[string]float64{"H": 0.0, "L": 0.1, "N": 0.2}
var scLevels = map[string]float64{"H": 0.1, "L": 0.2, "N": 0.3}
var siLevels = map[string]float64{"S": 0.0, "H": 0.1, "L": 0.2, "N": 0.3}
var saLevels = map[string]float64{"S": 0.0, "H": 0.1, "L": 0.2, "N": 0.3}
var crLevels = map[string]float64{"H": 0.0, "M": 0.1, "L": 0.2}
var irLevels = map[string]float64{"H": 0.0, "M": 0.1, "L": 0.2}
var arLevels = map[string]float64{"H": 0.0, "M": 0.1, "L": 0.2}

var metricLevels = map[string]map[string]float64{
	"AV": avLevels, "PR": prLevels, "UI": uiLevels,
	"AC": acLevels, "AT": atLevels,
	"VC": vcLevels, "VI": viLevels, "VA": vaLevels,
	"SC": scLevels, "SI": siLevels, "SA": saLevels,
	"CR": crLevels, "IR": irLevels, "AR": arLevels,
}

var distanceMetrics = []string{
	"AV", "PR", "UI", "AC", "AT", "VC", "VI", "VA", "SC", "SI", "SA", "CR", "IR", "AR",
}

// m resolves the effective value of a metric, honoring Environmental (M*) overrides.
func m(selected map[string]string, metric string) string {
	value, ok := selected[metric]
	if !ok {
		value = "X"
	}

	if metric == "E" && value == "X" {
		return "A"
	}
	if (metric == "CR" || metric == "IR" || metric == "AR") && value == "X" {
		return "H"
	}

	if modified, ok := selected["M"+metric]; ok && modified != "X" {
		return modified
	}
	return value
}

// macroVector computes the 6-digit MacroVector (EQ1..EQ6) for a CVSS v4.0 vector.
func macroVector(selected map[string]string) string {
	avv, prv, uiv := m(selected, "AV"), m(selected, "PR"), m(selected, "UI")
	var eq1 int
	if avv == "N" && prv == "N" && uiv == "N" {
		eq1 = 0
	} else if (avv == "N" || prv == "N" || uiv == "N") && avv != "P" {
		eq1 = 1
	} else {
		eq1 = 2
	}

	acv, atv := m(selected, "AC"), m(selected, "AT")
	eq2 := 1
	if acv == "L" && atv == "N" {
		eq2 = 0
	}

	vc, vi, va := m(selected, "VC"), m(selected, "VI"), m(selected, "VA")
	var eq3 int
	if vc == "H" && vi == "H" {
		eq3 = 0
	} else if vc == "H" || vi == "H" || va == "H" {
		eq3 = 1
	} else {
		eq3 = 2
	}

	msi, msa := m(selected, "MSI"), m(selected, "MSA")
	sc, si, sa := m(selected, "SC"), m(selected, "SI"), m(selected, "SA")
	var eq4 int
	if msi == "S" || msa == "S" {
		eq4 = 0
	} else if si == "H" || sa == "H" || sc == "H" {
		eq4 = 1
	} else {
		eq4 = 2
	}

	e := m(selected, "E")
	eq5 := map[string]int{"A": 0, "P": 1, "U": 2}[e]

	cr, ir, ar := m(selected, "CR"), m(selected, "IR"), m(selected, "AR")
	eq6 := 1
	if (cr == "H" && vc == "H") || (ir == "H" && vi == "H") || (ar == "H" && va == "H") {
		eq6 = 0
	}

	digits := []int{eq1, eq2, eq3, eq4, eq5, eq6}
	out := make([]byte, len(digits))
	for i, d := range digits {
		out[i] = byte('0' + d)
	}
	return string(out)
}

func extractValue(metric, vector string) string {
	idx := indexOf(vector, metric)
	rest := vector[idx+len(metric)+1:]
	slash := indexOf(rest, "/")
	if slash > 0 {
		return rest[:slash]
	}
	return rest
}

func indexOf(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}

func getEqMaxes(mv string, eq int) []string {
	return maxComposed["eq"+string(rune('0'+eq))][string(mv[eq-1])]
}

// BaseScoreV4 computes the CVSS v4.0 base score for a resolved metric->value mapping
// (every key in MetricValues must be present, defaulting to "X" where not selected).
func BaseScoreV4(selected map[string]string) float64 {
	allZeroImpact := true
	for _, metric := range []string{"VC", "VI", "VA", "SC", "SI", "SA"} {
		if m(selected, metric) != "N" {
			allZeroImpact = false
			break
		}
	}
	if allZeroImpact {
		return 0.0
	}

	mv := macroVector(selected)
	value := lookup[mv]

	eq1, eq2, eq3, eq4, eq5, eq6 := int(mv[0]-'0'), int(mv[1]-'0'), int(mv[2]-'0'), int(mv[3]-'0'), int(mv[4]-'0'), int(mv[5]-'0')

	digitStr := func(a, b, c, d, e, f int) string {
		return string([]byte{byte('0' + a), byte('0' + b), byte('0' + c), byte('0' + d), byte('0' + e), byte('0' + f)})
	}

	eq1Lower := digitStr(eq1+1, eq2, eq3, eq4, eq5, eq6)
	eq2Lower := digitStr(eq1, eq2+1, eq3, eq4, eq5, eq6)

	var eq3eq6LowerCandidates []string
	switch {
	case eq3 == 1 && eq6 == 1:
		eq3eq6LowerCandidates = []string{digitStr(eq1, eq2, eq3+1, eq4, eq5, eq6)}
	case eq3 == 0 && eq6 == 1:
		eq3eq6LowerCandidates = []string{digitStr(eq1, eq2, eq3+1, eq4, eq5, eq6)}
	case eq3 == 1 && eq6 == 0:
		eq3eq6LowerCandidates = []string{digitStr(eq1, eq2, eq3, eq4, eq5, eq6+1)}
	case eq3 == 0 && eq6 == 0:
		eq3eq6LowerCandidates = []string{
			digitStr(eq1, eq2, eq3, eq4, eq5, eq6+1),
			digitStr(eq1, eq2, eq3+1, eq4, eq5, eq6),
		}
	default:
		eq3eq6LowerCandidates = []string{digitStr(eq1, eq2, eq3+1, eq4, eq5, eq6+1)}
	}

	eq4Lower := digitStr(eq1, eq2, eq3, eq4+1, eq5, eq6)
	eq5Lower := digitStr(eq1, eq2, eq3, eq4, eq5+1, eq6)

	scoreEq1Lower, hasEq1Lower := lookup[eq1Lower]
	scoreEq2Lower, hasEq2Lower := lookup[eq2Lower]

	var scoreEq3Eq6Lower float64
	hasEq3Eq6Lower := false
	if len(eq3eq6LowerCandidates) == 2 {
		left, hasLeft := lookup[eq3eq6LowerCandidates[0]]
		right, hasRight := lookup[eq3eq6LowerCandidates[1]]
		switch {
		case !hasLeft && !hasRight:
			hasEq3Eq6Lower = false
		case !hasLeft:
			scoreEq3Eq6Lower, hasEq3Eq6Lower = right, true
		case !hasRight:
			scoreEq3Eq6Lower, hasEq3Eq6Lower = left, true
		default:
			if left > right {
				scoreEq3Eq6Lower = left
			} else {
				scoreEq3Eq6Lower = right
			}
			hasEq3Eq6Lower = true
		}
	} else {
		scoreEq3Eq6Lower, hasEq3Eq6Lower = lookup[eq3eq6LowerCandidates[0]]
	}

	scoreEq4Lower, hasEq4Lower := lookup[eq4Lower]
	_, hasEq5Lower := lookup[eq5Lower]

	eq1Maxes := getEqMaxes(mv, 1)
	eq2Maxes := getEqMaxes(mv, 2)
	eq3Eq6Maxes := maxComposedEq3[string(mv[2])][string(mv[5])]
	eq4Maxes := getEqMaxes(mv, 4)
	eq5Maxes := getEqMaxes(mv, 5)

	var distances map[string]float64
	for _, eq1Max := range eq1Maxes {
		for _, eq2Max := range eq2Maxes {
			for _, eq3Eq6Max := range eq3Eq6Maxes {
				for _, eq4Max := range eq4Maxes {
					for _, eq5Max := range eq5Maxes {
						maxVector := eq1Max + eq2Max + eq3Eq6Max + eq4Max + eq5Max
						candidate := map[string]float64{}
						allNonNeg := true
						for _, metric := range distanceMetrics {
							d := metricLevels[metric][m(selected, metric)] - metricLevels[metric][extractValue(metric, maxVector)]
							candidate[metric] = d
							if d < 0 {
								allNonNeg = false
							}
						}
						if allNonNeg {
							distances = candidate
							goto found
						}
					}
				}
			}
		}
	}
found:

	distEq1 := distances["AV"] + distances["PR"] + distances["UI"]
	distEq2 := distances["AC"] + distances["AT"]
	distEq3Eq6 := distances["VC"] + distances["VI"] + distances["VA"] + distances["CR"] + distances["IR"] + distances["AR"]
	distEq4 := distances["SC"] + distances["SI"] + distances["SA"]

	const step = 0.1
	maxSevEq1 := float64(maxSeverityEq1[eq1]) * step
	maxSevEq2 := float64(maxSeverityEq2[eq2]) * step
	maxSevEq3Eq6 := float64(maxSeverityEq3Eq6[eq3][eq6]) * step
	maxSevEq4 := float64(maxSeverityEq4[eq4]) * step

	nExistingLower := 0
	normalizedTotal := 0.0

	if hasEq1Lower {
		nExistingLower++
		normalizedTotal += (value - scoreEq1Lower) * (distEq1 / maxSevEq1)
	}
	if hasEq2Lower {
		nExistingLower++
		normalizedTotal += (value - scoreEq2Lower) * (distEq2 / maxSevEq2)
	}
	if hasEq3Eq6Lower {
		nExistingLower++
		normalizedTotal += (value - scoreEq3Eq6Lower) * (distEq3Eq6 / maxSevEq3Eq6)
	}
	if hasEq4Lower {
		nExistingLower++
		normalizedTotal += (value - scoreEq4Lower) * (distEq4 / maxSevEq4)
	}
	if hasEq5Lower {
		// eq5's proportion is always 0 per the reference implementation.
		nExistingLower++
	}

	meanDistance := 0.0
	if nExistingLower != 0 {
		meanDistance = normalizedTotal / float64(nExistingLower)
	}

	result := value - meanDistance
	result = math.Max(0.0, math.Min(10.0, result))
	return roundHalfAway(result+epsilon, 1)
}
